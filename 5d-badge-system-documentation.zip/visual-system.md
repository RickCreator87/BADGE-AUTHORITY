# Visual System and 5D Badge Rendering Specification

## 1. Visual Design Philosophy

The visual system transforms cryptographic state into compelling, dynamically evolving graphical representations. The design philosophy centers on three core principles: cryptographic anchoring ensures that every visual element derives from verifiable cryptographic operations; dimensional progression creates a sense of emergence as the badge evolves through stages; and adaptive aesthetics ensures the badge looks exceptional across all devices from high-end desktops to mobile phones.

The badge is not merely a decorative element but a cryptographic instrument that communicates verification status through visual language. Each visual transformation corresponds to a specific cryptographic event, creating an intuitive understanding of the verification process. Users can glance at the badge and immediately comprehend the verification state without needing to understand the underlying cryptographic operations.

## 2. Defining the Five Dimensions

### 2.1 First Dimension: The Linear Chain

The first dimension represents the hash chain itself—the linear sequence of cryptographic operations that underpin the entire system. While invisible in the final visual, this dimension provides the foundation upon which all other dimensions are built. The chain length determines which stages are available and influences visual parameters through hash-derived values.

This dimension is represented through the badge's "identity"—the unique visual signature that distinguishes one badge from another. Two badges at the same stage will appear similar in structure but distinct in color, animation timing, and subtle details, all derived from their unique hash chains.

### 2.2 Second Dimension: Flat Representation

The second dimension introduces the initial flat graphical representation—the starting point from which all subsequent evolution occurs. At stage zero, the badge appears as a two-dimensional graphic lying in a plane.

The flat representation features a core design element that will remain recognizable as the badge evolves. This might be a logo, an icon, or an abstract shape depending on the application context. The flat stage serves as the baseline from which depth is extruded and provides a clear visual anchor for subsequent transformations.

The flat graphic is rendered using vector graphics principles, ensuring crisp display at any resolution. Gradients and subtle textures add visual interest without creating performance demands on mobile devices.

### 2.3 Third Dimension: Volumetric Depth

The third dimension introduces genuine three-dimensionality through depth extrusion. The flat graphic extrudes into a three-dimensional form, gaining volume and the ability to interact with light.

The extrusion follows a procedural algorithm based on the badge's hash:

```
extrusionDepth = (hash[0] mod 16) / 8 + 0.5  // Range: 0.5 to 2.5 units
extrusionPattern = hash[1] mod 4  // Determines bevel/chamfer style
detailLevel = hash[2] mod 8 + 1  // Surface detail iterations
```

Three distinct geometric families are used depending on the hash value:

- **Crystalline**: Faceted surfaces with sharp edges, appropriate for trust/verification themes
- **Organic**: Smooth flowing surfaces with subtle undulations, appropriate for natural products
- **Geometric**: Clean angular forms with mathematical precision, appropriate for financial/governance themes

Lighting interacts with the depth through a combination of baked ambient occlusion and real-time directional lighting. The primary light source rotates slowly around the badge, revealing form and creating dynamic highlights.

### 2.4 Fourth Dimension: Temporal Animation

The fourth dimension introduces time-based variation—animation that makes the badge feel alive and responsive. Animation is not arbitrary but tied to cryptographic parameters, creating a unique temporal signature for each badge.

Animation parameters derive from the hash chain:

```
animationSpeed = (chainLength * 0.1) + (hash[4] mod 10) / 10  // Base speed modifier
animationPhase = hash[5] / 255  // Starting phase offset
pulseFrequency = 0.5 + (hash[6] mod 20) / 10  // Range: 0.5 to 2.5 Hz
```

Several animation types are available:

**Rotation**: The badge rotates around its vertical axis at varying speeds. Higher stages include additional axes of rotation, creating more complex motion patterns.

**Surface Flow**: Pixels or surface elements flow across the badge surface in patterns determined by the hash. At stage three, this appears as subtle shimmering; at higher stages, it becomes more pronounced.

**Breathing**: The badge expands and contracts rhythmically, simulating organic life. The pulse rate can be synchronized to external factors such as block time.

**Particle Emission**: At the highest stages, particles may emanate from the badge surface, representing verification energy or data flow.

### 2.5 Fifth Dimension: Contextual Reactivity

The fifth dimension represents the badge's ability to respond to external context—adapting its appearance based on real-world conditions beyond the hash chain. This creates a sense of the badge being "aware" of its environment.

Contextual parameters include:

**Network Conditions**: The badge's glow intensity and color temperature respond to blockchain network congestion. High gas prices might make the badge appear more subdued, while favorable conditions cause it to glow more brightly.

**Temporal Context**: The badge responds to time of day and season. Night hours might bring a cooler color temperature; festival seasons might add celebratory particles.

**User Interaction**: When users interact with the badge (clicking, hovering, dragging), the badge responds with reactive animations that provide tactile feedback.

**Event Proximity**: The badge pulses more rapidly as significant events approach. In a shipping context, the badge pulses faster as the package nears delivery.

## 3. Rendering Pipeline Architecture

### 3.1 Shader-Based Rendering

The visual system uses custom shaders (GLSL) for all badge rendering, enabling the procedural generation of visual elements and efficient adaptation to different performance levels.

The rendering pipeline follows a multi-pass approach:

**Pass 1 - Geometry Generation**: The badge mesh is generated procedurally based on stage and hash parameters. Vertex positions, normals, and UV coordinates are computed on the GPU.

**Pass 2 - Base Material**: The primary material is rendered using signed distance field (SDF) techniques for smooth curves and efficient anti-aliasing. Material properties (color, roughness, metallic) derive from hash parameters.

**Pass 3 - Depth Effects**: Screen-space depth is computed for post-processing effects. This enables soft edge glow, depth of field, and ambient occlusion.

**Pass 4 - Lighting**: Multiple light sources are accumulated, including environment maps for reflections. The lighting model supports physically-based rendering (PBR) for realistic material appearance.

**Pass 5 - Post-Processing**: Final effects are applied including bloom, chromatic aberration, vignette, and color grading. These effects operate on the full rendered frame.

### 3.2 Signed Distance Field Techniques

Signed distance fields (SDFs) provide the foundation for badge geometry and effects. An SDF defines the distance to the nearest surface point for each position in space, enabling infinite resolution scaling and efficient boolean operations.

For badge geometry, SDFs enable smooth blending between primitive shapes:

```
float sdBox(vec3 p, vec3 b) {
    vec3 q = abs(p) - b;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float sdSphere(vec3 p, float s) {
    return length(p) - s;
}

// Smooth union for blending shapes
float opSmoothUnion(float d1, float d2, float k) {
    float h = clamp(0.5 + 0.5 * (d2 - d1) / k, 0.0, 1.0);
    return mix(d2, d1, h) - k * h * (1.0 - h);
}
```

This technique enables the badge to morph smoothly between geometric forms as it advances through stages, creating visually pleasing transitions rather than jarring swaps.

### 3.3 Visual Parameter Derivation

Visual parameters are deterministically derived from the cryptographic hash using a structured derivation process:

```
function deriveVisualParams(hash: bytes32): VisualParams {
    // Color parameters (hue, saturation, value)
    params.hue = (hash[0] / 255) * 360;
    params.saturation = 0.5 + (hash[1] / 255) * 0.5;
    params.value = 0.7 + (hash[2] / 255) * 0.3;

    // Animation parameters
    params.rotationSpeed = 0.2 + (hash[3] / 255) * 0.8;
    params.pulseRate = 0.5 + (hash[4] / 255) * 2.0;
    params.flowSpeed = 0.1 + (hash[5] / 255) * 0.4;

    // Geometry parameters
    params.complexity = 1 + (hash[6] / 255) * 4;
    params.distortion = (hash[7] / 255) * 0.3;

    // Effect parameters
    params.glowIntensity = 0.3 + (hash[8] / 255) * 0.7;
    params.particleCount = floor(10 + (hash[9] / 255) * 90);

    return params;
}
```

This derivation ensures that the same hash chain always produces the same visual appearance while creating distinct badges for different chains.

## 4. Stage Progression System

### 4.1 Stage Definitions

Each stage represents a milestone in the verification process and triggers specific visual transformations:

**Stage 0 - Genesis**

- Geometry: Flat 2D shape in XY plane
- Material: Solid color with subtle gradient
- Animation: None (static)
- Effects: None
- Transition: None required (initial state)

**Stage 1 - Extrusion**

- Geometry: 3D extrusion of base shape
- Material: Added metallic sheen, subtle normal mapping
- Animation: Slow Y-axis rotation (0.2 rad/s)
- Effects: Soft edge glow
- Transition: 2-second extrusion animation, vertices displace outward from plane

**Stage 2 - Illumination**

- Geometry: Same as Stage 1, added surface detail
- Material: Full PBR material, environment reflections
- Animation: Rotation continues, added subtle surface shimmer
- Effects: Colored glow emanating from core, bloom
- Transition: 1.5-second glow fade-in, color derived from hash

**Stage 3 - Animation**

- Geometry: Surface deformation begins
- Material: Animated UV distortion for flowing effect
- Animation: Multiple rotation axes, pixel flow across surface
- Effects: Chromatic aberration on glow, particle emission begins
- Transition: 2-second flow animation, surface begins undulation

**Stage 4 - Breathing**

- Geometry: Pulsing scale oscillation
- Material: Emission intensity tied to pulse
- Animation: Rhythmic expansion/contraction, faster rotation
- Effects: Strong particle systems, screen shake on pulse peaks
- Transition: 1-second pulse initialization, smooth acceleration to target rate

**Stage 5 - Contextual**

- Geometry: Full reactive form
- Material: All effects active, responds to context
- Animation: All animations active, context-modulated
- Effects: Full particle systems, dynamic lighting response
- Transition: 0.5-second enhancement animation, context hooks activate

### 4.2 Transition Animations

Transitions between stages are critical for maintaining visual coherence and user experience quality. Abrupt changes feel jarring and unpolished; smooth transitions create a sense of organic growth and progression.

The transition system uses GLSL mix functions for parameter interpolation:

```
// Easing function for smooth transitions
float easeInOutCubic(float t) {
    return t < 0.5
        ? 4.0 * t * t * t
        : 1.0 - pow(-2.0 * t + 2.0, 3.0) / 2.0;
}

// Vertex displacement for extrusion
vec3 extrudeVertex(vec2 flatPos, float progress, float depth) {
    float easedProgress = easeInOutCubic(progress);
    return vec3(flatPos.x, flatPos.y, easedProgress * depth);
}
```

Transitions can be interrupted and reversed if the chain state rolls back (due to re-org or correction). The system maintains both source and target states during transition, enabling smooth reversal.

### 4.3 Visual Coherence

While each badge is unique, visual coherence across the system ensures users can instantly recognize a 5D badge regardless of individual variations. Core design elements remain consistent:

**Silhouette Recognition**: The overall silhouette of the badge (its outline shape) follows common patterns regardless of hash variation. Users learn to recognize the badge shape.

**Effect Vocabulary**: The types of effects used (glow, rotation, particles) remain consistent even as parameters vary. This creates a visual language users can interpret.

**Stage Semantics**: Each stage carries consistent semantic meaning. Users learn that Stage 3 always involves visible animation, regardless of what that animation looks like specifically.

## 5. Color System

### 5.1 Hash-Derived Color

The primary color palette derives from the cryptographic hash, ensuring uniqueness while maintaining aesthetic quality. The derivation algorithm prioritizes:

**Visual Appeal**: Not all hash values produce pleasing colors. The derivation algorithm maps hash bytes through a curated palette or adjusts saturation/value to ensure visual appeal regardless of hue.

**Stage-Appropriate Intensity**: Lower stages use more muted colors; higher stages activate more vibrant, saturated hues.

**Context Compatibility**: The color derivation considers the typical display context (dark backgrounds, light backgrounds) and ensures visibility in common viewing conditions.

### 5.2 Semantic Coloring

Beyond hash-derived colors, the system uses semantic colors for specific states:

**Verification Green**: Used for successful verification events, communicates trust and completion

**Warning Amber**: Used for pending verifications or incomplete states

**Alert Red**: Used for failed verifications or expired credentials

**Neutral Gray**: Used for unverified or inactive states

**Gold/Prismatic**: Used for special achievements or premium features

### 5.3 Glow and Emission

The glow effect is central to the badge's visual appeal. The emission model uses:

```
vec3 calculateGlow(vec3 worldPos, vec3 viewPos, float stage) {
    vec3 glowColor = baseColor * (1.0 + stage * 0.5);
    float fresnel = pow(1.0 - dot(normalize(viewPos - worldPos), normal), 3.0);
    float intensity = fresnel * glowIntensity * stage;
    return glowColor * intensity;
}
```

The glow responds to viewing angle (Fresnel effect), creating edges that appear to emit light. At higher stages, multiple glow layers create complex, ethereal effects.

## 6. Animation System

### 6.1 Procedural Animation

All animations are procedurally generated rather than pre-recorded, enabling infinite variation and perfect synchronization with cryptographic parameters.

Key procedural animation techniques include:

**Noise-Based Deformation**: Perlin or Simplex noise creates organic surface movement. The noise field scrolls over time, creating flowing patterns across the surface.

**L-Systems**: Grammar-based plant growth algorithms create particle emission patterns and surface tendrils at higher stages.

**Physics Simulation**: Simple physics (gravity, spring dynamics) creates natural-feeling motion for particles and reactive elements.

### 6.2 Animation Controllers

Animation is managed through a hierarchical controller system:

**Global Controller**: Sets overall animation time, handles stage transitions, manages performance-based animation complexity reduction

**Layer Controllers**: Individual controllers for rotation, pulse, flow, and particles, each with independent parameters

**Reactive Controller**: Monitors user interaction and context, triggers reactive animations in response

This hierarchical design enables fine-grained control over animation while maintaining system-level coordination.

### 6.3 Performance-Aware Animation

Animation complexity automatically scales based on available performance:

```
function calculateAnimationBudget(fps: number, targetFPS: number): Budget {
    if (fps >= targetFPS) {
        return Budget.Full;
    } else if (fps >= targetFPS * 0.7) {
        return Budget.Reduced;  // Disable particles, simplify shaders
    } else if (fps >= targetFPS * 0.5) {
        return Budget.Minimal;  // Only rotation, no glow
    } else {
        return Budget.Static;   // No animation
    }
}
```

This ensures the badge remains responsive even on constrained devices while still delivering the best experience possible.

## 7. Post-Processing Effects

### 7.1 Bloom

Bloom creates the ethereal glow effect around bright areas of the badge. The effect uses a multi-pass approach:

1. Extract bright pixels (threshold-based)
2. Apply Gaussian blur at multiple scales
3. Blend blurred result with original image

Bloom intensity scales with badge stage:

- Stage 0-1: No bloom
- Stage 2: Subtle bloom (10% intensity)
- Stage 3: Moderate bloom (25% intensity)
- Stage 4: Strong bloom (40% intensity)
- Stage 5: Intense bloom with chromatic separation (50%+ intensity)

### 7.2 Chromatic Aberration

At higher stages, subtle chromatic aberration adds visual complexity. RGB channels are slightly offset based on distance from the badge center:

```
vec3 applyChromaticAberration(vec2 uv, vec2 center, float strength) {
    vec2 dir = uv - center;
    float dist = length(dir);
    vec2 offset = dir * dist * strength;

    return vec3(
        texture(tex, uv + offset).r,
        texture(tex, uv).g,
        texture(tex, uv - offset).b
    );
}
```

### 7.3 Additional Effects

**Depth of Field**: Subtle DOF at stage 5 emphasizes the 3D nature of the badge

**Vignette**: Darkened corners focus attention on the badge center

**Film Grain**: Subtle noise adds texture, particularly at lower tiers

**Color Grading**: Final color adjustment ensures consistent color across stages and devices

## 8. Accessibility Considerations

### 8.1 Reduced Motion

Users with motion sensitivity can enable reduced motion preferences. The system respects the `prefers-reduced-motion` media query and automatically adjusts:

- Reduce or eliminate rotation
- Replace flowing animations with static gradient shifts
- Disable particle effects
- Extend transition durations to reduce perceived motion

### 8.2 High Contrast Mode

For users with visual impairments, high contrast mode adjusts the badge:

- Maximum saturation and value
- Strong edge definition
- High contrast glow against dark backgrounds
- Increased base scale

### 8.3 Screen Reader Support

The badge provides accessibility metadata for screen readers:

- Current stage announced on change
- Semantic meaning of stage (verified, pending, etc.)
- Animated status indicators with ARIA live regions
- Keyboard navigation for badge interaction

## 9. Implementation Technologies

### 9.1 Three.js and React-Three-Fiber

The primary rendering technology is Three.js, accessed through React-Three-Fiber for React-based applications. This combination provides:

- Declarative scene composition
- Automatic resource management
- Integration with React state and lifecycle
- Extensive ecosystem of examples and extensions

### 9.2 Custom Shaders

GLSL shaders provide the core visual effects. Shaders are authored in raw GLSL and compiled at runtime:

```
const vertexShader = `
varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;

void main() {
    vUv = uv;
    vNormal = normalize(normalMatrix * normal);
    vPosition = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const fragmentShader = `
uniform float uTime;
uniform vec3 uColor;
uniform float uStage;

varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;

void main() {
    vec3 lightDir = normalize(vec3(1.0, 1.0, 1.0));
    float diff = max(dot(vNormal, lightDir), 0.0);

    vec3 color = uColor * (0.3 + 0.7 * diff);
    color += vec3(0.1) * uStage; // Glow increases with stage

    gl_FragColor = vec4(color, 1.0);
}
`;
```

### 9.3 WebGL and WebGPU

The renderer supports both WebGL 1.0/2.0 and WebGPU for backward and forward compatibility:

- WebGL 1.0: Baseline support for older devices
- WebGL 2.0: Advanced effects, better performance
- WebGPU: Future-proofing for next-generation applications

The renderer automatically selects the best available API and provides fallbacks for unsupported features.
