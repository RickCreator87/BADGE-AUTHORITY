# Mobile-Adaptive Pixel System Specification

## 1. Mobile Rendering Philosophy

The mobile-adaptive pixel system represents a critical component of the 5D Badge architecture, ensuring that the cryptographic visual experience reaches users across the entire spectrum of device capabilities. Mobile devices present unique challenges: limited computational resources, constrained battery life, thermal throttling concerns, and varied screen resolutions. Rather than treating these constraints as limitations to work around, the system embraces a philosophy of degradation aesthetics—transforming performance constraints into intentional visual styles that maintain the badge's core identity while optimizing for the target platform.

The fundamental principle underlying this philosophy is that every user deserves a high-quality badge experience, regardless of their device's capabilities. A user on a flagship smartphone should experience the badge differently than a user on a budget device, but both experiences should feel intentional, polished, and cryptographically authentic. The mobile-adaptive system ensures this equity of experience through careful design and sophisticated adaptation algorithms.

This document details the technical implementation of the adaptive pixel system, including device capability detection, tiered rendering strategies, dynamic performance management, and battery optimization techniques. The goal is to provide a complete blueprint for implementing mobile-optimized badge rendering that maintains visual integrity while respecting device limitations.

## 2. Device Capability Assessment

### 2.1 Initial Capability Detection

Upon application launch, the renderer performs a comprehensive capability assessment to determine the optimal rendering tier. This assessment examines multiple factors that influence rendering performance:

**Graphics API Support**: The system tests for WebGL 2.0 support, falling back to WebGL 1.0 if necessary. Where available, WebGPU is preferred for its improved performance characteristics. The detection sequence follows this priority: WebGPU > WebGL 2.0 > WebGL 1.0.

**Hardware Acceleration**: The system queries renderer capabilities to identify available features: maximum texture size, maximum vertex attributes, float texture support, and instanced rendering support. These values inform the selection of appropriate rendering techniques.

**Screen Properties**: The system captures screen resolution, pixel density (DPR), and refresh rate. High-DPR displays require more GPU resources for equivalent visual quality; high refresh rate displays require more frequent frame rendering.

**Device Memory**: Where available, the system queries device memory through the Navigator API. Low-memory devices (typically 2GB or less) receive more conservative rendering tiers.

**CPU Cores**: The number of available logical processors informs parallel processing capabilities. While not directly used in rendering, this affects how much work can be offloaded from the main thread.

The capability assessment produces a capability score:

```
capabilityScore = (
    apiWeight * apiScore +
    hardwareWeight * hardwareScore +
    memoryWeight * memoryScore +
    displayWeight * displayScore
) / totalWeight
```

This score maps to initial tier selection through a thresholding function.

### 2.2 Runtime Performance Monitoring

Static capability detection provides only an initial tier selection. Runtime monitoring ensures the system adapts to actual performance conditions, which may differ from theoretical capabilities due to thermal throttling, background processes, or application behavior.

The monitoring system tracks key performance metrics:

**Frame Time**: The duration of each rendered frame, measured from the start of one frame to the start of the next. Frame time should remain below 33.33ms for 30 FPS playback.

**Frame Rate**: Calculated as the inverse of frame time, averaged over a rolling window of 60 frames to smooth out variance.

**GPU Utilization**: Where available through the Performance API, GPU time is tracked to identify when the graphics processor is saturated.

**Memory Pressure**: JavaScript heap usage is monitored; growth patterns indicate potential memory pressure that could trigger garbage collection pauses.

The monitoring system maintains a performance history buffer and calculates trend indicators:

```
performanceTrend = (recentAverage - baselineAverage) / baselineAverage
```

A negative trend (recent performance worse than baseline) triggers tier reduction; a positive trend (recent performance better than baseline) may trigger tier increase after a stabilization period.

## 3. Tiered Rendering System

### 3.1 Tier Definitions

The rendering system defines four distinct tiers, each representing a specific balance between visual fidelity and computational cost:

**Tier 1 - Maximum Fidelity**: This tier delivers the full visual experience with all effects enabled. Raymarching shaders provide infinite-resolution geometry. Volumetric fog creates atmospheric depth. Real-time reflections render the environment. Anti-aliasing smooths edges. High polygon counts enable detailed geometry. This tier targets gaming desktops, high-end laptops, and flagship mobile devices. Target performance: 60 FPS.

**Tier 2 - Balanced**: This tier maintains high visual quality while reducing computational demands. Standard polygon meshes replace raymarched geometry. Baked lighting replaces real-time calculations in most cases. Simple bloom provides glow without expensive blur passes. Moderate polygon counts balance detail with performance. This tier targets modern smartphones, tablets, and mid-range laptops. Target performance: 30-60 FPS.

**Tier 3 - Performance**: This tier prioritizes smooth operation over visual complexity. Voxel-style rendering provides a distinctive aesthetic that embraces pixelation as a style choice rather than a limitation. Simplified shaders reduce instruction count. Low polygon counts minimize vertex processing. This tier targets older smartphones, budget devices, and users with battery saver enabled. Target performance: 30 FPS.

**Tier 4 - Essential**: This tier ensures basic functionality on severely constrained devices. 2D rendering with pseudo-3D effects replaces true 3D. Static or minimal animation keeps power consumption minimal. This tier targets very old devices and extreme power-saving modes. Target performance: 15-30 FPS.

### 3.2 Tier Transition Criteria

Transitions between tiers occur based on sustained performance conditions:

**Tier Reduction Trigger**:

- Frame rate below 24 FPS for 5 consecutive seconds
- Frame rate below 20 FPS for 3 consecutive seconds
- Device temperature exceeds threshold (thermal throttling detected)
- Battery level below 15% with battery saver enabled
- Memory pressure detected (heap growth rate exceeds threshold)

**Tier Increase Trigger**:

- Frame rate above 55 FPS for 10 consecutive seconds
- Device temperature returned to normal after throttling
- Battery level above 50% and charging
- Memory pressure resolved

Hysteresis in these thresholds prevents rapid oscillation between tiers. The system requires sustained performance improvement before upgrading and tolerates brief performance dips before reducing.

### 3.3 Per-Tier Feature Matrix

The following matrix details which features are enabled at each tier:

| Feature | Tier 1 | Tier 2 | Tier 3 | Tier 4 |
|---------|--------|--------|--------|--------|
| Raymarching | Yes | No | No | No |
| Volumetric Fog | Yes | No | No | No |
| Real-time Reflections | Yes | No | No | No |
| Anti-aliasing | MSAA 4x | FXAA | None | None |
| Bloom | Full | Simple | Minimal | None |
| Particles | Full | Reduced | Simple | None |
| Animation Complexity | High | Medium | Low | Minimal |
| Polygon Count | High | Medium | Low | Minimal |
| Texture Resolution | Full | 75% | 50% | 25% |
| Post-Processing | Full | Basic | None | None |

## 4. Pixelation Degradation Strategy

### 4.1 Philosophy of Intentional Degradation

A naive approach to mobile optimization would simply reduce resolution, resulting in blurry, soft-edged graphics that appear broken or unoptimized. The mobile-adaptive system instead embraces the pixelation as an intentional aesthetic—the "degradation" becomes a deliberate style choice that maintains visual clarity while reducing computational load.

This approach draws from the pixel art tradition, where constraints become creative opportunities. Users on lower-tier devices receive a badge that looks retro and stylish rather than broken and substandard. The distinctive pixel aesthetic also serves as a visual indicator of device capabilities, which users often appreciate as a form of device identity expression.

### 4.2 Framebuffer Object Technique

The pixelation effect is implemented through a framebuffer object (FBO) rendering strategy:

1. Render the badge scene to a low-resolution render target
2. Apply pixel-level effects in the low-resolution space
3. Upscale the result to the display resolution using nearest-neighbor filtering

This approach differs from CSS-based pixelation in that the entire rendering pipeline operates at reduced resolution, including lighting calculations, post-processing, and effects. The computational savings are proportional to the resolution reduction.

The resolution multiplier is tier-dependent:

```
pixelRatio = tier match {
    Tier 1 => 1.0,
    Tier 2 => 0.75,
    Tier 3 => 0.5,
    Tier 4 => 0.25
}
```

At Tier 3 (pixel ratio 0.5), a 1920x1080 display renders at 960x540, then upscales. This provides 75% reduction in per-frame pixel processing while maintaining the distinctive pixel aesthetic.

### 4.3 Pixel Shader Effects

In addition to geometric pixelation, the pixel system includes shader-based pixel effects that activate at lower tiers:

**Dithering**: Where continuous tone gradients would show banding at reduced color depth, ordered dithering adds noise that masks color transitions. This creates a retro aesthetic reminiscent of early computer graphics.

**Limited Palette**: Color quantization reduces the available color space to a defined palette (e.g., 64 colors). This reduces color computation and creates a cohesive visual style.

**Edge Enhancement**: To compensate for softened edges at low resolution, edge detection sharpens contours. This maintains visual clarity while preserving the pixel aesthetic.

**Scanline Overlay**: Optional horizontal lines evoke CRT displays, adding nostalgic character to the pixel rendering.

These effects are implemented as part of the fragment shader and add minimal computational overhead while significantly enhancing the aesthetic quality of low-resolution rendering.

## 5. Dynamic Resolution Scaling

### 5.1 Per-Frame Resolution Adjustment

Beyond tier-based scaling, the system implements dynamic resolution scaling that adjusts resolution in real-time based on instantaneous performance. This provides fine-grained adaptation that responds to momentary fluctuations in available resources.

The dynamic scaling algorithm operates as follows:

1. Measure frame time for current frame
2. Calculate target frame time based on desired FPS (e.g., 33.33ms for 30 FPS)
3. Compute scaling factor: if frame time exceeds target, reduce resolution; if well below target, increase resolution
4. Apply smoothing: resolution changes are gradual, preventing jarring visual shifts
5. Clamp to tier limits: dynamic scaling cannot exceed the tier's maximum resolution

The smoothing function prevents flicker:

```
smoothedScale = lerp(currentScale, targetScale, smoothingFactor)
smoothingFactor = 0.1  // Gradual transition over ~10 frames
```

### 5.2 Resolution Bounds

Each tier defines minimum and maximum resolution bounds that dynamic scaling cannot exceed:

- Tier 1: 0.8 to 1.0 of native resolution
- Tier 2: 0.5 to 0.75 of native resolution
- Tier 3: 0.25 to 0.5 of native resolution
- Tier 4: 0.125 to 0.25 of native resolution

These bounds ensure that even with dynamic scaling, the visual tier identity remains recognizable.

### 5.3 Content-Aware Scaling

Advanced implementations may analyze scene content to prioritize resolution where it matters most. For example, the badge center (containing the primary visual subject) might maintain higher resolution than the background. This "foveated" approach mimics human visual attention and maximizes perceived quality at minimal computational cost.

Content-aware scaling requires additional analysis passes to identify scene regions, increasing implementation complexity. This is considered an optimization for future implementation rather than a core requirement.

## 6. Battery Optimization

### 6.1 Power Consumption Factors

Mobile device battery life is a critical concern for users. The badge rendering system must balance visual quality against power consumption to avoid rapid battery depletion.

Primary power consumption factors include:

**GPU Utilization**: Continuous GPU activity drains battery. Higher frame rates, more complex shaders, and larger render targets all increase GPU power draw.

**Screen Brightness**: The display backlight is often the largest power consumer. Rendering at native resolution on high-DPR displays increases power consumption significantly.

**CPU Activity**: JavaScript processing, garbage collection, and background tasks consume CPU power and trigger screen activity.

**Network Activity**: While typically minor compared to rendering, network communication for badge updates can contribute to power consumption, especially on cellular connections.

### 6.2 Battery-Aware Adaptation

The system integrates with the Battery Status API (where available) to adjust rendering based on power state:

```
navigator.getBattery().then(battery => {
    battery.addEventListener('levelchange', handleBatteryChange);
    battery.addEventListener('chargingchange', handleChargingChange);
});

function handleBatteryChange() {
    if (battery.level < 0.15 && !battery.charging) {
        requestTierReduction();
    }
}
```

Battery-aware adaptations include:

- Forcing Tier 3 or below when battery is critically low
- Reducing frame rate target from 60 to 30 FPS when not charging
- Disabling non-essential effects (particles, post-processing) on battery
- Increasing the tier reduction threshold sensitivity on battery

### 6.3 Visibility-Based Optimization

When the badge is not visible (e.g., tab is backgrounded, app is minimized), rendering should pause entirely to conserve power. The Page Visibility API provides the necessary hooks:

```
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        pauseRendering();
    } else {
        resumeRendering();
    }
});
```

Upon resuming visibility, the system performs a quick performance assessment and may temporarily operate at reduced tier before ramping up to the stable tier.

## 7. Network and Data Optimization

### 7.1 Badge State Synchronization

The badge requires periodic synchronization with the cryptographic core to receive updates. Network efficiency is critical for mobile devices, particularly on cellular connections.

The synchronization protocol uses delta updates:

```
// Full state includes all parameters
fullState = {
    badgeId: string,
    stage: number,
    chainLength: number,
    latestHash: string,
    visualParams: {...},
    timestamp: number
}

// Delta update includes only changed fields
deltaUpdate = {
    badgeId: string,
    changes: {
        stage: { old: 2, new: 3 },
        latestHash: "0x..."
    }
}
```

Clients cache the last known full state. When receiving updates, the client applies delta changes to the cached state. This minimizes data transfer while ensuring clients maintain complete state.

### 7.2 Asset Caching Strategy

Visual assets are cached aggressively to minimize network requests:

**Deterministic Assets**: Assets derived from hash parameters (generated procedurally) are never cached from the network; they are regenerated locally.

**Static Assets**: Icons, textures, and environment maps are cached using the Cache API with appropriate expiration headers.

**Badge State**: Previously viewed badge states are stored in IndexedDB for instant display on subsequent views and offline access.

The caching strategy uses a stale-while-revalidate approach: cached content is displayed immediately while background validation checks for updates. This provides instant display while ensuring content remains current.

### 7.3 Compression

All network data uses compression to minimize transfer size:

- Text data (JSON): Brotli compression where supported, gzip fallback
- Binary data: Protocol Buffers or similar binary encoding
- Images: WebP format with JPEG fallback for unsupported browsers

Compression decisions are negotiated between client and server through standard content negotiation headers.

## 8. Touch and Interaction

### 8.1 Mobile Gesture Support

The badge supports touch-based interaction on mobile devices:

**Tap**: Single tap triggers a "pulse" reactive animation, providing tactile feedback.

**Drag**: Horizontal drag rotates the badge around the Y-axis; vertical drag adjusts the viewing angle.

**Pinch**: Pinch gesture zooms the badge in and out within defined bounds.

**Long Press**: Long press triggers a detail view showing cryptographic verification information.

These interactions map directly to mouse equivalents on desktop, ensuring consistent experience across platforms.

### 8.2 Gesture Conflict Resolution

Badge interactions may conflict with page scrolling or other browser gestures. The system implements conflict resolution:

- Badge interactions require contact within the badge bounding box
- Gestures initiated outside the badge are passed to default handlers
- Vertical swipes within the badge are interpreted as badge rotation, not page scroll, when initiated on the badge

### 8.3 Haptic Feedback

Where supported (iOS Core Haptics, Android Vibration API), the badge provides haptic feedback:

- Light tap on state change
- Medium pulse on stage advancement
- Strong vibration on verification completion

Haptic feedback is disabled by default and requires user opt-in through settings, respecting accessibility preferences.

## 9. Platform-Specific Considerations

### 9.1 iOS Safari

iOS Safari presents specific challenges for WebGL rendering:

- **Limited WebGL Extensions**: Some advanced WebGL extensions are unavailable; the system detects and disables unsupported features gracefully.
- **Background Tab Suspension**: iOS aggressively suspends background tabs; the badge pauses and requires explicit resumption.
- **Memory Limits**: iOS imposes per-process memory limits; the system monitors memory and reduces tier proactively.
- ** notch Handling**: Safe area insets must be respected for badge positioning.

### 9.2 Android Chrome

Android Chrome offers better WebGL support but faces different challenges:

- **GPU Fragmentation**: Android devices use diverse GPUs with varying capabilities; feature detection is essential.
- **Battery Optimization**: Android's battery optimization may throttle background activity; the system adapts to aggressive power management.
- **Variable Refresh Rate**: Some Android devices support variable refresh rate displays; the system queries and adapts frame timing accordingly.

### 9.3 Cross-Platform Considerations

Cross-platform compatibility requires attention to common issues:

- **DPI Scaling**: Different browsers handle DPI differently; the system normalizes to logical pixels for consistent sizing.
- **Font Rendering**: Badge text uses system fonts to ensure consistent cross-platform appearance.
- **Input Normalization**: Pointer events API normalizes touch and mouse input; the system uses this for unified handling.

## 10. Testing and Quality Assurance

### 10.1 Device Lab Testing

Mobile rendering requires physical device testing beyond emulators:

- **Low-End Devices**: Budget Android phones, older iPhones (2-3 years old)
- **Mid-Range Devices**: Current mid-market phones, last year's flagships
- **High-End Devices**: Current flagship phones, gaming phones

The test matrix covers OS versions, browser versions, network conditions (WiFi, 4G, 3G, offline), and power states (charging, discharging, battery saver).

### 10.2 Performance Benchmarking

Synthetic benchmarks provide reproducible performance measurements:

- **Frame Time**: Average, 90th percentile, 99th percentile
- **Memory Usage**: Baseline, peak, post-GC
- **Battery Drain**: Measured percentage per hour of active viewing

Benchmarks run automatically on CI/CD infrastructure and flag regressions.

### 10.3 User Experience Validation

Technical metrics alone do not capture user experience quality:

- **Perceived Performance**: User testing to confirm badge feels responsive
- **Visual Quality**: Expert review to confirm aesthetic tier identity
- **Accessibility**: Testing with screen readers and accessibility tools
- **Battery Impact**: User testing to confirm acceptable battery drain

User experience validation complements technical testing to ensure the adaptive system delivers genuine quality.
