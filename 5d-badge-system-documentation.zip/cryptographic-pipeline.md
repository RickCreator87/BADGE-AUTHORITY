# Cryptographic Pipeline Specification

## 1. Cryptographic Design Philosophy

The cryptographic pipeline forms the foundational trust layer of the 5D Adaptive Badge System. Every visual transformation of the badge must be traceable to a cryptographic operation, creating an unbroken chain of custody from the original event to the displayed visual state. This design philosophy ensures that the badge cannot be spoofed, manipulated, or falsely represented without detection.

The pipeline operates on a fundamental principle: visual state derives deterministically from cryptographic state. Given the same sequence of events and the same cryptographic parameters, the badge will always display the same visual state. This determinism enables verification—any observer can independently compute the expected visual state from the cryptographic chain and compare it against what they see displayed.

The cryptographic design prioritizes three properties: integrity, authenticity, and efficiency. Integrity ensures that once an event is recorded in the chain, it cannot be modified or deleted. Authenticity ensures that only legitimate events from authorized sources are accepted into the chain. Efficiency ensures that the system can process high volumes of events without excessive computational cost or blockchain fees.

## 2. Hash Chain Architecture

### 2.1 Chain Structure

The hash chain serves as the primary data structure for maintaining cryptographic state. Each link in the chain contains a cryptographic hash that incorporates information from both the current event and all previous events. This creates a property where any modification to historical data would produce a different hash at every subsequent point in the chain, immediately revealing tampering.

Each chain element contains the following fields:

```
ChainElement {
    index: uint64,           // Position in chain (0 = genesis)
    timestamp: uint64,        // Unix timestamp of event
    eventHash: bytes32,       // Hash of the raw event data
    previousHash: bytes32,    // Hash of the previous chain element
    dataHash: bytes32,        // Hash of normalized event data
    metadata: bytes           // Additional metadata (encoded)
}
```

The genesis element (index 0) is a special case with previousHash set to all zeros. This anchors the chain to a known starting point that can be independently verified.

### 2.2 Hash Function Selection

The choice of hash function balances security requirements with performance constraints. For most applications, SHA-256 provides an excellent balance, offering 128-bit security against collision attacks while running efficiently on modern processors. The function processes events as follows:

```
eventHash = SHA256(normalizedEventData)
chainInput = SHA256(previousHash || eventHash || timestamp || nonce)
currentHash = SHA256(chainInput)
```

For applications requiring faster hashing or smaller hash sizes, BLAKE3 provides excellent performance while maintaining strong security properties. BLAKE3 is particularly suitable for client-side verification, where computational resources may be limited.

For applications with quantum computing concerns, the system can be configured to use SHAKE256 (a SHA-3 variant) with variable-length output, providing forward compatibility with post-quantum security requirements.

### 2.3 Event Hashing Process

The event hashing process transforms raw event data into a canonical hash representation. This process includes several critical steps to ensure consistent hashing regardless of event source format variations.

First, the event data is normalized into a canonical form. This involves parsing the source-specific format, extracting relevant fields, ordering fields in a deterministic way, and encoding the result in a consistent character encoding (UTF-8). The normalization ensures that semantically identical events from different sources produce the same hash.

Second, the normalized data is prepended with a domain separation string before hashing. This prevents hash collision attacks where an attacker might craft malicious data that hashes to match legitimate event data. The domain string is unique to the badge system and application:

```
domainSeparator = "5D-BADGE-V1-" || applicationId
eventHash = SHA256(domainSeparator || normalizedData)
```

Third, a nonce may be added to the hash input to enable proof-of-work style computational puzzles if desired. For most applications, a simple sequential nonce suffices, but for high-value transactions, additional proof-of-work can be required to make chain manipulation computationally expensive.

## 3. Merkle Tree Batching

### 3.1 Motivation for Batching

Recording every individual event directly to a blockchain would be prohibitively expensive for high-volume applications. Transaction fees, whether in Ethereum gas or other blockchain resources, scale with the number of on-chain operations. Additionally, blockchain confirmation times would introduce latency between event occurrence and badge visual update.

Merkle tree batching addresses both issues by aggregating multiple events into a single blockchain commitment. A Merkle tree is a binary tree data structure where each leaf node contains the hash of an event, and each non-leaf node contains the hash of its two children. The root of the tree (Merkle root) uniquely represents the entire set of events in the batch.

By committing only the Merkle root to the blockchain, the system reduces on-chain costs by a factor equal to the batch size. A batch of 100 events would require approximately 1% of the on-chain transactions compared to recording each event individually.

### 3.2 Merkle Tree Construction

The Merkle tree is constructed using a standard bottom-up approach. Given a list of event hashes, the tree is built as follows:

```
1. For each event, compute leafHash = SHA256(eventData)
2. Pair adjacent leafHashes and compute parentHash = SHA256(left || right)
3. Repeat step 2 until a single root remains
4. If odd number of nodes at any level, duplicate the last node
```

The resulting Merkle root provides a cryptographic commitment to all events in the batch. Anyone with the individual event data can independently compute the Merkle proof showing that the event was included in the batch.

### 3.3 Proof Generation and Verification

Merkle proofs enable efficient verification that a specific event was included in a committed batch without requiring the entire batch data. The proof consists of the event's leaf hash, the sibling hashes along the path to the root, and the root hash itself.

Proof generation proceeds as follows for an event at position i:

```
proof = []
currentHash = leafHash(i)
for each level from bottom to top:
    if i is even:
        proof.append(rightSibling)
        currentHash = SHA256(currentHash || rightSibling)
    else:
        proof.append(leftSibling)
        currentHash = SHA256(leftSibling || currentHash)
    i = i // 2
proof.append(root)
```

Proof verification simply recomputes the root hash using the provided proof and compares it against the committed root:

```
currentHash = leafHash
for each sibling in proof (excluding final root):
    if direction is left:
        currentHash = SHA256(sibling || currentHash)
    else:
        currentHash = SHA256(currentHash || sibling)
return currentHash == committedRoot
```

## 4. Zero-Knowledge Proof Integration

### 4.1 Privacy Requirements

Many applications require privacy protections that conflict with the transparency of a public hash chain. For example, a badge representing identity verification might need to prove that the user has passed KYC checks without revealing which documents were verified or when verification occurred. A badge representing financial status might need to prove solvency without revealing account balances.

Zero-knowledge proofs (ZKPs) address these requirements by allowing one party (the prover) to convince another party (the verifier) that a statement is true without revealing any information beyond the validity of the statement itself. In the context of the badge system, ZKPs enable proving badge state properties without revealing the underlying event data.

### 4.2 zk-SNARK Implementation

The system implements zero-knowledge proofs using zk-SNARKs (Zero-Knowledge Succinct Non-Interactive Arguments of Knowledge). This technology provides compact proofs that are quick to verify and reveal nothing beyond the proven statement.

For badge applications, the primary use case is proving that the badge has reached a certain stage (e.g., passed compliance checks) without revealing the specific events that triggered the stage advancement. The circuit for this proof operates as follows:

```
Public Input: currentStage, MerkleRoot, chainLength
Private Input: eventHashes[], stageTransitions[]

// Verify all events hash to leaves in the Merkle tree
for each event in events:
    merkleProof = computeMerkleProof(event)
    verify(merkleProof, MerkleRoot)

// Verify stage transitions are valid
currentStage = 0
for each transition in stageTransitions:
    assert(transition.validates(currentStage, eventHash))
    currentStage = transition.resultingStage

// Verify final stage matches public input
assert(currentStage == publicInput.currentStage)
```

The resulting proof can be verified by anyone knowing only the public inputs, proving that the badge genuinely reached the claimed stage through valid cryptographic operations without revealing the underlying events.

### 4.3 Groth16 and PLONK

The system supports multiple ZK proving systems to balance proof size, verification time, and setup requirements.

Groth16 requires a trusted setup phase but produces the smallest proofs and fastest verification times. This makes Groth16 suitable for applications where proof verification happens frequently, such as on-chain verification in smart contracts.

PLONK (Permutations over Lagrange-bases for Oecumenical Noninteractive arguments of Knowledge) offers universal setup—once generated, the proving key can be used for any circuit of a given size. This simplifies deployment for applications where the circuit may evolve over time.

## 5. Soulbound Token Integration

### 5.1 Badge as Non-Transferable Asset

The badge can be implemented as a Soulbound Token (SBT), a non-fungible token that cannot be transferred once minted. SBTs represent personal credentials or achievements that should remain permanently associated with the holder's address.

By implementing the badge as an SBT, the system gains several advantages. First, the badge becomes a portable, verifiable credential that the holder can present to third parties. Second, the badge's history becomes part of the blockchain's permanent record, providing immutable proof of verification history. Third, the badge can participate in the broader ecosystem of NFT-based applications and marketplaces.

### 5.2 ERC-5192 Implementation

The system implements the ERC-5192 standard for soulbound NFTs, which provides a minimal interface for locking NFTs to specific addresses:

```
interface IERC5192 {
    /// @notice Emitted when the locking status changes
    event Locked(address owner, uint256 tokenId);

    /// @notice Returns the locking status of the token
    /// @param tokenId The token to query
    /// @return True if the token is locked (soulbound), false otherwise
    function locked(uint256 tokenId) external view returns (bool);
}
```

The badge token URI points to dynamically generated JSON containing the current visual state parameters. When the badge advances to a new stage, the metadata is updated to reflect the new visual parameters, triggering a re-render on all clients displaying the badge.

### 5.3 Dynamic Metadata

The token metadata follows the ERC-721 metadata standard with extensions for dynamic state:

```
{
    "name": "5D Verification Badge",
    "description": "Cryptographically verified verification badge showing workflow progress",
    "image": "https://cdn.example.com/badge/render/0x1234.png",
    "attributes": [
        {
            "trait_type": "Stage",
            "value": 3,
            "display_type": "number"
        },
        {
            "trait_type": "ChainLength",
            "value": 47,
            "display_type": "number"
        },
        {
            "trait_type": "LastUpdate",
            "value": 1699876543,
            "display_type": "date"
        },
        {
            "trait_type": "VisualSeed",
            "value": "0x7a2b..."
        }
    ],
    "dynamic_attributes": {
        "visual_params": {
            "hue": 210,
            "saturation": 0.75,
            "rotation_speed": 0.5,
            "animation_mode": "flowing_pixels"
        }
    }
}
```

The dynamic attributes encode the parameters needed to regenerate the badge's visual appearance from the cryptographic state. Clients can verify that the displayed badge matches the on-chain metadata by recomputing the visual parameters from the hash chain.

## 6. Anti-Spoofing Mechanisms

### 6.1 Steganographic Watermarking

A sophisticated attacker might attempt to capture a high-stage badge display (via screen recording) and present it as their own live badge. The system addresses this through steganographic watermarking—embedding invisible markers in every rendered frame that prove the frame was generated in real-time from the current cryptographic state.

The watermark is computed as follows: given the current block hash (or latest chain hash), compute a watermark pattern using a deterministic algorithm. Embed this pattern into the badge's visual output by slightly adjusting pixel values, shader parameters, or geometry in ways imperceptible to casual observation but detectable by verification software.

The watermark encodes the current timestamp and chain state, creating a temporal component that prevents replay attacks. Anyone attempting to verify a badge display can extract the watermark and confirm it corresponds to recent cryptographic state.

### 6.2 Real-Time Verification API

The system provides a verification API that clients can call to confirm the displayed badge state is current:

```
GET /api/v1/verify/{badgeId}

Response:
{
    "valid": true,
    "currentStage": 3,
    "chainLength": 47,
    "latestHash": "0xabcd...",
    "latestEvent": {
        "type": "VERIFICATION_PASSED",
        "timestamp": 1699876543
    },
    "verificationProof": {
        "merkleRoot": "0xdef0...",
        "merkleProof": "..."
    }
}
```

Clients displaying the badge should periodically call this API to confirm their displayed state matches the authoritative source. Significant discrepancies indicate potential manipulation or synchronization issues.

### 6.3 Chain Reorganization Handling

Blockchain systems occasionally experience reorganizations (re-orgs) where the canonical chain changes due to network forks or temporary consensus disagreements. The cryptographic pipeline must handle re-orgs gracefully to prevent the badge from displaying invalid states.

When a re-org is detected, the system performs the following steps:

1. Identify the fork point where the chains diverge
2. Roll back all chain elements after the fork point
3. If badge was displayed based on rolled-back elements, trigger visual "glitch" effect
4. Re-fetch events from the new canonical chain
5. Re-compute badge state from the corrected chain
6. Animate transition to the corrected visual state

The visual glitch effect serves an important purpose: it signals to observers that the badge state has changed due to external factors rather than natural progression, maintaining trust in the badge's integrity.

## 7. Cryptographic Key Management

### 7.1 Key Hierarchy

The system employs a hierarchical key structure to separate concerns and limit exposure:

```
Master Key (Offline, Cold Storage)
    |
    +-- Signing Key (HSM, Production Use)
    |       |
    |       +-- Event Signing Key
    |       +-- State Signing Key
    |       +-- Metadata Signing Key
    |
    +-- Oracle Key (Application-Specific)
            |
            +-- Source Authentication Key
            +-- Event Validation Key
```

The master key remains offline in hardware security module (HSM) storage and is used only for key rotation ceremonies. The signing key operates from an HSM in production, signing state attestations and metadata updates. Oracle keys are distributed to individual Event Oracle instances and can be rotated independently.

### 7.2 Signing Operations

State attestations are signed using ECDSA with the secp256k1 curve (compatible with Ethereum):

```
attestation = {
    badgeId: bytes32,
    stage: uint8,
    chainLength: uint64,
    latestHash: bytes32,
    timestamp: uint64,
    nonce: uint64
}

signature = ECDSA.sign(attestation, signingKey)
```

Clients verify signatures using the system's published public key. The public key is embedded in the client application and can be rotated through software updates if compromise is suspected.

## 8. Performance Optimization

### 8.1 Event Processing Throughput

The cryptographic pipeline must handle high event volumes without introducing unacceptable latency. The system achieves this through several optimization strategies.

First, events are processed asynchronously with confirmation batching. The Oracle receives events and immediately acknowledges receipt, then processes them in the background. This prevents slow event processing from blocking event ingestion.

Second, hash computation uses hardware acceleration where available. Modern CPUs support SHA-NI (SHA extensions) that accelerate SHA-256 computation by 2-4x. The pipeline detects and uses these extensions automatically.

Third, Merkle tree computation is parallelized for large batches. Modern JavaScript runtimes (Node.js with worker threads) can compute tree levels in parallel, significantly reducing batch processing time.

### 8.2 Caching Strategies

Frequently accessed cryptographic data is cached at multiple levels to reduce computation and database load:

**Redis Cache Layer**: The Cryptographic Core maintains a Redis cache of recent chain elements, frequently requested proofs, and current badge states. Cache invalidation follows TTL-based expiration with explicit invalidation on chain updates.

**Client-Side Cache**: Clients maintain local IndexedDB storage of viewed badge states. This enables instant display of previously viewed badges and offline verification capability.

**CDN Caching**: Public verification data and badge metadata are served through a CDN with appropriate cache headers, reducing load on origin servers.

## 9. Compliance and Audit

### 9.1 Audit Logging

All cryptographic operations are logged to an immutable audit trail:

```
AuditEntry {
    timestamp: uint64,
    operation: enum,
    actor: address,
    inputHash: bytes32,
    outputHash: bytes32,
    chainIndex: uint64,
    metadata: bytes
}
```

Logs are written to append-only storage and periodically committed to the blockchain as a hash commitment, ensuring long-term integrity.

### 9.2 Regulatory Compliance

The system supports compliance requirements through configurable privacy features. Zero-knowledge proofs enable compliance without full transparency. Data retention policies can be implemented through key rotation, where old keys are retired and event data is archived after the retention period expires.

For GDPR compliance, the system supports data deletion through chain truncation—the hash chain can be pruned to remove references to deleted data while maintaining cryptographic integrity for remaining data.

## 10. Cryptographic Agility

### 10.1 Algorithm Migration

The cryptographic pipeline is designed for algorithm migration, enabling future upgrades to stronger or more efficient algorithms without disrupting existing badge chains.

Migration operates through a versioning mechanism in the chain elements:

```
ChainElement {
    ...
    algorithmVersion: uint16,  // Identifies hash function and parameters
    legacyHash: bytes32,       // Hash using old algorithm (for compatibility)
    primaryHash: bytes32       // Hash using current algorithm
}
```

During a migration period, both old and new algorithm hashes are included, enabling verification by clients using either algorithm version. After migration completes, old algorithm support can be deprecated.

### 10.2 Post-Quantum Readiness

For long-term security against quantum computing threats, the system can be configured to use hash-based signatures (such as SPHINCS+) for state signing. While these signatures are larger than ECDSA, they provide security even against quantum computers.

The hash chain itself is already quantum-resistant, as hash function output cannot be reversed even by quantum computers (using Grover's algorithm, security is reduced but not eliminated).
