
class EvolutionEngine:

    def analyze_repo(self, files):
        suggestions = []
        if "tests" not in files:
            suggestions.append("Add test suite")
        return suggestions

    def refine_prompt(self, prompt):
        return prompt + "\n# refined by evolution engine"
