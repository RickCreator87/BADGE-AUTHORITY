
# AI Self-Copilot System

An AI system that acts as its own GitHub‑Copilot‑style assistant.

## Components

- **Copilot Brain**
- **Backend Gateway (FastAPI)**
- **VS Code Extension**
- **GitHub App**
- **Self Evolution Engine**
- **Developer Assistants**

## Install

```bash
git clone repo
cd ai-copilot-system
python -m venv venv
source venv/bin/activate
pip install -r backend/requirements.txt
```

## Run Backend

```bash
uvicorn backend.main:app --reload
```

## Run Tests

```bash
pytest
```

## API

| Endpoint | Purpose |
|---|---|
| /suggest | code suggestions |
| /review | PR review |
| /explain | explain code |
| /refactor | refactor suggestions |
| /tests | generate tests |
| /governance/validate | rule validation |

## Architecture

```mermaid
flowchart TD
A[VSCode Extension]
B[GitHub App]
C[Backend Gateway]
D[Copilot Brain]
E[Assistants]
F[Self Evolution]

A --> C
B --> C
C --> D
D --> E
D --> F
```
