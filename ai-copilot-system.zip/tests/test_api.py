
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_suggest():
    r = client.post("/suggest", json={"code":"print(1)"})
    assert r.status_code == 200
