
module.exports = (app) => {

app.on("pull_request.opened", async context => {
const pr = context.payload.pull_request;
await context.octokit.issues.createComment(
context.issue({
body: "AI Maintainer: reviewing this PR automatically."
})
);
});

};
