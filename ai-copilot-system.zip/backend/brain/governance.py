
def validate_code(payload):
    code = payload.get("code","")
    banned = ["eval(", "exec("]
    issues = [b for b in banned if b in code]
    return {
        "valid": len(issues) == 0,
        "issues": issues
    }
