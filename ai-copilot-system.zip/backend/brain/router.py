
def route_model(task, payload):
    code = payload.get("code","")
    if task == "suggest":
        return {"suggestion": f"# improved version\n{code}"}
    if task == "review":
        return {"review": "Code looks valid but consider adding tests."}
    if task == "explain":
        return {"explanation": "This code performs a computation."}
    if task == "refactor":
        return {"refactor": code}
    if task == "tests":
        return {"tests": "def test_example(): assert True"}
    return {"error": "unknown task"}
