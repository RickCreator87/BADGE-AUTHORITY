
from fastapi import FastAPI
from brain.router import route_model
from brain.governance import validate_code

app = FastAPI(title="AI Copilot Backend")

@app.post("/suggest")
def suggest(payload: dict):
    return route_model("suggest", payload)

@app.post("/review")
def review(payload: dict):
    return route_model("review", payload)

@app.post("/explain")
def explain(payload: dict):
    return route_model("explain", payload)

@app.post("/refactor")
def refactor(payload: dict):
    return route_model("refactor", payload)

@app.post("/tests")
def tests(payload: dict):
    return route_model("tests", payload)

@app.post("/governance/validate")
def governance(payload: dict):
    return validate_code(payload)
