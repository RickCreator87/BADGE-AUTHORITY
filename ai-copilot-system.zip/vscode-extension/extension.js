
const vscode = require('vscode');
const axios = require('axios');

function activate(context){

const disposable = vscode.commands.registerCommand('ai.explain', async function () {

const editor = vscode.window.activeTextEditor;
const code = editor.document.getText(editor.selection);

const res = await axios.post('http://localhost:8000/explain',{code});
vscode.window.showInformationMessage(res.data.explanation);

});

context.subscriptions.push(disposable);

}

function deactivate(){}

module.exports = { activate, deactivate }
